package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.Entity.Customer;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		Customer customer=new Customer();
		
		
		String strid=request.getParameter("txtId");
		
		if(strid!=null)
		{
			int id=Integer.parseInt(strid);
			customer.setId(id);
			
		}
		
		
		String name=request.getParameter("txtName");
        if(name!=null)
		{
			
			customer.setName(name);
			
		}
        
        String gen=request.getParameter("gender");
        if(gen!=null)
        {
        	int gender=Integer.parseInt(gen);
        	customer.setGender(gender);
        }
        
        String isPreveliged=request.getParameter("checkPrevilege");
        if(isPreveliged==null)
        {
        	customer.setPrivilege(false);
        }
        else
        {
        	customer.setPrivilege(true);
        }
        
        String email=request.getParameter("Email");
        if(email!=null)
        {
        	customer.setEmail(email);
        }
        
        String phone=request.getParameter("phone");
        if(phone!=null)
        {
        	customer.setPhone(phone);
        }
        
        String address=request.getParameter("address");
        if(address!=null)
        {
        	customer.setAddress(address);
        }
        
       String doj=request.getParameter("txtDoj");
       if(doj!=null)
       {
    	   SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
    	   Date doj1=null;
		try {
			doj1 = format.parse(doj);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	   customer.setDateOfJoining(doj1);
       }
       
       
       
       String desc=request.getParameter("txtDesc");
       if(desc!=null)
       {
       	
       	customer.setDescription(desc);
       	
       }
        
       
       
       String balance=request.getParameter("balance");
       if(balance!=null)
       {
       	double bal=Double.parseDouble(balance);
       customer.setBalanceAmount(bal);
       	
       }
       
       
       String rate=request.getParameter("txtRating");
       if(rate!=null)
       {
       	int r=Integer.parseInt(rate);
       customer.setCustomerRating(r);
       	
       }
        
		
		out.println(customer.getName());
		
		out.println(customer.getId());
		out.println(customer.getPhone());
		out.println(customer.getEmail());
		out.println(customer.getGender());
		out.println(customer.getBalanceAmount());
		out.println(customer.getAddress());
		out.println(customer.getCustomerRating());
		out.println(customer.getDescription());
		out.println(customer.getDateOfJoining());
		out.println(customer.isPrivilege());
		
		
		
		
	}

}
